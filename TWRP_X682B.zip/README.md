# android_device_infinix_X682B
TWRP tree for Infinix Hot 10/10T(X682B) to build TWRP touch recovery
